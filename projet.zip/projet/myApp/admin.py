from django.contrib import admin

# Register your models here.
from .models import Users, Orders


class UsersAdmin(admin.ModelAdmin):
    def admin(self):
        if self.admin:
            return "Admin"
        else:
            return ""
    admin.short_description = ""
    list_display = ['pk', 'username', 'password', admin]
    list_filter = ['admin']
    search_fields = ['username']
    fields = ['username', 'password', 'admin']


class OrdersAdmin(admin.ModelAdmin):
    list_display = ['name', 'price', 'image', 'user']
    list_filter = ['user']
    search_fields = ['user']

    fields = ['name', 'price', 'image', 'user']


admin.site.register(Users, UsersAdmin)

admin.site.register(Orders, OrdersAdmin)
