from django.db import models


# Create your models here.


class Users(models.Model):
    password = models.CharField(max_length=10)
    username = models.CharField(max_length=10)
    admin = models.BooleanField(default=False)

    def model_to_dict(self):
        return {"username": self.username, "password": self.password, "admin": self.admin}

    # def __str__(self):
    # return "name=%s password=%s" % (self.username, self.password)


class Orders(models.Model):
    name = models.CharField(max_length=10)
    price = models.FloatField()
    image = models.CharField(max_length=20)
    user = models.ForeignKey("Users")

    def model_to_dict(self):
        return {"name": self.name, "price": self.price, "user": self.user.username}

    # def __str__(self):
    # return "name=%s price=%f immage=%s" % (self.name, self.price, self.image)
