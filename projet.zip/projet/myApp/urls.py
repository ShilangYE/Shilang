from django.conf.urls import url, include

from . import views

urlpatterns = [
    url(r'^index/', views.index, name='index'),
    url(r'^(\d+)$', views.detail),
    url(r'^users/$', views.users),
    url(r'^orders/$', views.orders),
    url(r'^order/$', views.order),
    url(r'^user/$', views.users)
]