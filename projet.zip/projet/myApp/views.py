from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse, JsonResponse
from .models import Users, Orders


def index(request):
    return HttpResponse("Une application web")
    # user = Users.objects.get(pk=1)
    # return render(request, 'myApp/index.')


def detail(request, num):
    return HttpResponse("detail-%s" % num)


def users(request):
    userslist = Users.objects.all()
    return render(request, 'myApp/users.html', {"users": userslist})


def user(request):
    userslist = Users.objects.all()
    return render(request, 'myApp/user.html', {"users": userslist})


def orders(request):
    orderslist = Orders.objects.all()
    return render(request, 'myApp/orders.html', {"orders": orderslist})


def order(request):
    return JsonResponse({'result': 200, 'success': True, 'msg': 'ok'})
