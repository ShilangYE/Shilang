$(function () {
    $.getJSON("/api/orders/", function (data) {
        console.log(data);
            var $container = $("#container");
            var order_list = data['data'];

          for(var i =0 ; i<order_list.length;i++){
            console.log(order_list[i]);

            var $tr = $("<tr></tr>");

            var $p_pk = $("<td></td>");
            $p_pk.html(i + 1);
            $tr.append($p_pk);
            $container.append($tr);

            var $td_price = $("<td></td>");
            $td_price.html(order_list[i]['price']);
            $td_price.append("€")
            $tr.append($td_price);
            $container.append($tr);

            var $td_user= $("<td></td>");
            $td_user.html(order_list[i]['user']);
            $tr.append($td_user);
            $container.append($tr);


        }
    })

})