$(function () {
    $.getJSON("/api/users/", function (data) {
        console.log(data);
            var $container = $("#container");
            var user_list = data['data'];

          for(var i =0 ; i<user_list.length;i++){
            console.log(user_list[i]);

            var $tr = $("<tr></tr>");

            var $p_pk = $("<td></td>");
            $p_pk.html(i + 1);
            $tr.append($p_pk);
            $container.append($tr);

            var $p_username = $("<td></td>");
            $p_username.html(user_list[i]['username']);
            $tr.append($p_username);
            $container.append($tr);


            if(user_list[i]['admin']) {
                var $p_admin = $("<td class='admin'>Admin</td>");
            }
            else
                var $p_admin = $("<td></td>");
            $tr.append($p_admin);
            $container.append($tr);



        }
    })

})