from django.http import JsonResponse, HttpResponse, QueryDict
from django.shortcuts import render
from flask import jsonify, json

from django.http.multipartparser import MultiPartParser

# Create your views here.
from django.views.decorators.csrf import csrf_exempt

from myApp.models import Users, Orders


def index(request):
    data = {
        'status': 200,
        'msg': 'ok'
    }
    return JsonResponse(data=data)


@csrf_exempt
def users(request):
    if request.method == "GET":
        user_list = Users.objects.all()
        user_list_json = []
        for user in user_list:
            user_list_json.append(user.model_to_dict())
        data = {
            'status': 201,
            'msg': 'get ok',
            'data': user_list_json
        }
        return JsonResponse(data=data)
    elif request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        admin = request.POST.get("admin")

        user = Users()
        user.username = username
        user.password = password
        user.admin = admin
        user.save()

        data = {
            'status': 201,
            'msg': 'add success',
            'data': user.model_to_dict()
        }

        return JsonResponse(data=data, status=201)


@csrf_exempt
def user(request, userid):
    if request.method == "GET":
        user_obj = Users.objects.get(pk=userid)
        data = {
            'msg': 'ok',
            'status': 200,
            'data': user_obj.model_to_dict()
        }
        return JsonResponse(data=data)
    elif request.method == "DELETE":
        user_obj = Users.objects.get(pk=userid)
        user_obj.delete()
        data = {
            'status': 204,
            'msg': 'delete success',
            'data': {}
        }
        return JsonResponse(data=data)
    elif request.method == "PUT":
        user_obj = Users.objects.get(pk=userid)
        put = MultiPartParser(request.META, request, request.upload_handlers).parse()
        username = put[0].get('username')
        print(username)
        password = put[0].get('password')
        print(password)
        admin = put[0].get("admin")
        if username:
            user_obj.username = username
        if password:
            user_obj.password = password
        if admin:
            user_obj.admin = admin
        user_obj.save()
        data = {
            'status': 201,
            'msg': 'change success',
            'data': user_obj.model_to_dict()
        }

        return JsonResponse(data=data)


@csrf_exempt
def orders(request):
    if request.method == "GET":
        order_list = Orders.objects.all()
        order_list_json = []
        for order in order_list:
            order_list_json.append(order.model_to_dict())
        data = {
            'status': 201,
            'msg': 'get ok',
            'data': order_list_json
        }
        return JsonResponse(data=data)
    elif request.method == "POST":
        name = request.POST.get('name')
        price = request.POST.get('price')
        username = request.POST.get("user")

        order = Orders()
        user_list = Users.objects.all()
        for user1 in user_list:
            if user1.username == username:
                order.user = user1
        order.name = name
        order.price = price
        order.save()

        data = {
            'status': 201,
            'msg': 'add success',
            'data': order.model_to_dict()
        }

        return JsonResponse(data=data, status=201)


@csrf_exempt
def order(request, orderid):
    if request.method == "GET":
        order_obj = Orders.objects.get(pk=orderid)
        data = {
            'msg': 'ok',
            'status': 200,
            'data': order_obj.model_to_dict()
        }
        return JsonResponse(data=data)
    elif request.method == "DELETE":
        order_obj = Orders.objects.get(pk=orderid)
        order_obj.delete()
        data = {
            'status': 204,
            'msg': 'delete success',
            'data': {}
        }
        return JsonResponse(data=data)
    elif request.method == "PUT":
        order_obj = Orders.objects.get(pk=orderid)
        put = MultiPartParser(request.META, request, request.upload_handlers).parse()
        name = put[0].get('name')
        price = put[0].get('price')
        usernew = put[0].get("user")
        if name:
            order_obj.name = name
        if price:
            order_obj.price = price
        if usernew:
            user_list = Users.objects.all()
            for user1 in user_list:
                if user1.username == usernew:
                    order_obj.user = user1
        order_obj.save()
        data = {
            'status': 201,
            'msg': 'change success',
            'data': order_obj.model_to_dict()
        }

        return JsonResponse(data=data)
