from django.conf.urls import url

from Api import views

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^users/$', views.users, name='users'),
    url(r'^users/(?P<userid>\d+)/', views.user, name='user'),
    url(r'^orders/$', views.orders, name='orders'),
    url(r'^orders/(?P<orderid>\d+)/', views.order, name='order'),
]